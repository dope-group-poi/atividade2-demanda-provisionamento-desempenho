# Rodada c1_1vcpu_1gb

- Provisionamento informado pelo usuário: 1 vCPU e 1 GB de RAM. Não verificado diretamente no VirtualBox.
- Gerador de carga executado no host, acessando localhost nas portas 8001, 8002 e 8003.
- Aplicações testadas sequencialmente: CPU, memória e I/O.
- Concorrência: 1, 10 e 50 clientes em todas as aplicações.
- 200 requisições por combinação, uma rodada por aplicação.
- CPU: size=100,200,300.
- Memória: mb=64,128,256.
- I/O: delay_ms=50,100,200; file_mb=4.
- Os processos das aplicações não foram reiniciados pelo gerador entre as etapas.
- CPU e memória são amostradas pelo endpoint /stats; métricas do processo podem representar apenas um worker se houver múltiplos workers.
- Latências e vazão consideram respostas bem-sucedidas. Falhas são contabilizadas em errors.
- Os gráficos usam apenas os arquivos *_summary.csv de cada aplicação.
- A rodada anterior interrompida foi preservada em cpu_rodada_interrompida e não é usada nos gráficos desta rodada.

## Estado dos resultados

- CPU: 9 combinações, 1.800 respostas bem-sucedidas, nenhum erro.
- I/O: 9 combinações, 1.800 respostas bem-sucedidas, nenhum erro.
- Memória: 4 respostas bem-sucedidas e 1.796 erros. A aplicação deixou de responder na primeira combinação (64 MB, concorrência 1). As etapas posteriores registram indisponibilidade e não são medições válidas de desempenho.
- Valores zero de latência e recursos nas etapas sem respostas/amostras de memória representam ausência de dados no coletor, não latência ou consumo efetivamente nulos.
- A causa da indisponibilidade de memória exige consulta aos logs do serviço e do kernel na VM; não foi confirmada pelo gerador de carga.
